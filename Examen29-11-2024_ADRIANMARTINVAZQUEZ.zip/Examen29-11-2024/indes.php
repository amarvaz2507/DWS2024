<?php
    include 'metodos.php'; //Incluimos el fichero de php metodos.php
    if ($_SERVER["REQUEST_METHOD"] === "POST") { //Comprobamos si el formulario se ha enviado o no
        
    }else{

    }
?>
<form method="get" action="index.php">
        
    </form>
